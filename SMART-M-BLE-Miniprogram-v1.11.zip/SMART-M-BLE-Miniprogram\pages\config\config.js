/**
 * SMART-M 蓝牙监控小程序 — 设备配置页
 *
 * 通过 BLE 修改设备（STM32）的 WiFi 热点参数与云平台（华为云 IoTDA MQTT）
 * 连接参数，固件保存在内部 Flash，掉电不丢失；保存后 MQTT 任务自动按新
 * 配置重连，无需重启设备。
 *
 * 协议（一行一帧 JSON，\r\n 结尾）：
 *   查询: {"cmd":"GETCFG"}
 *   应答: {"ok":1,"cmd":"GETCFG","wifi_ssid":"...","wifi_password":"...",
 *          "broker_host":"...","broker_ip":"...","broker_port":1883,
 *          "client_id":"...","username":"...","password":"...","device_id":"..."}
 *   修改: {"cmd":"SETCFG","wifi_ssid":"...","wifi_password":"...",...}
 *         缺省字段保留当前值；应答 {"ok":1,"cmd":"SETCFG","saved":1}
 *
 * 注意：字符串字段不允许包含 " 和 \（固件轻量 JSON 解析限制）。
 */
const app = getApp()

const SERVICE_UUID = app.globalData.SERVICE_UUID
const NOTIFY_CHAR_UUID = app.globalData.NOTIFY_CHAR_UUID
const WRITE_CHAR_UUID = app.globalData.WRITE_CHAR_UUID

Page({
  data: {
    adapterReady: false,
    discovering: false,
    connected: false,
    deviceId: '',
    deviceName: '',
    devices: [],
    showAllDevices: true,   // true=显示全部蓝牙设备（默认），false=只显示 BT24
    loadingCfg: false,
    saving: false,
    // 网络配置表单
    wifi_ssid: '',
    wifi_password: '',
    broker_host: '',
    broker_ip: '',
    broker_port: '1883',
    client_id: '',
    username: '',
    password: '',
    device_id: '',
    logs: []
  },

  onLoad() {
    this._notifyHandler = null
    this._connStateHandler = null
    this._deviceFoundHandler = null
    this._rxBuffer = ''
    this._writeQueue = Promise.resolve()
    this._serviceId = ''
    this._notifyCharId = ''
    this._writeCharId = ''
  },

  onUnload() {
    this.cleanup()
  },

  onHide() {
    if (this.data.discovering) {
      wx.stopBluetoothDevicesDiscovery({ complete: () => {} })
    }
  },

  /* ---------------- 工具 ---------------- */

  log(msg) {
    const logs = this.data.logs
    logs.push(`[${new Date().toLocaleTimeString()}] ${msg}`)
    if (logs.length > 60) logs.shift()
    this.setData({ logs })
  },

  showToast(title, icon = 'none') {
    wx.showToast({ title, icon, duration: 2200 })
  },

  onClearLog() {
    this.setData({ logs: [] })
  },

  /* ---------------- 蓝牙：打开 / 扫描 / 连接 ---------------- */

  onOpenAdapter() {
    wx.openBluetoothAdapter({
      success: () => {
        this.setData({ adapterReady: true })
        this.log('蓝牙适配器已打开')
        this.onStartScan()
      },
      fail: (err) => {
        const ec = err && err.errCode
        let tip = '打开蓝牙失败'
        if (ec === 10001) tip = '蓝牙未开启或无权限，请到系统设置打开并授权'
        else if (ec === 10002) tip = '未获得蓝牙权限，请在设置中允许'
        else if (ec === 10003) tip = 'Android 需开启系统定位服务才能扫描'
        this.showToast(tip)
        this.log('打开蓝牙失败: ' + JSON.stringify(err))
      }
    })
  },

  onStartScan() {
    if (this.data.discovering) return
    this.setData({ devices: [], discovering: true })

    // 先注销旧回调，避免多次重扫累积重复处理器
    if (this._deviceFoundHandler) {
      wx.offBluetoothDeviceFound(this._deviceFoundHandler)
    }
    this._deviceFoundHandler = (res) => {
      const found = (res.devices || []).map((d) => {
        const name = d.name || d.localName || ''
        const uuids = (d.advertisServiceUUIDs || []).map((u) => u.toUpperCase())
        return {
          deviceId: d.deviceId,
          name: name || '未知设备',
          rssi: d.RSSI,
          // 名称含 BT24 或广播含 FFE0 服务 → 判定为透传模块
          isBt24: name.toLowerCase().indexOf('bt24') >= 0 ||
                  uuids.some((u) => u.indexOf(SERVICE_UUID) >= 0)
        }
      }).filter((d) => {
        return this.data.showAllDevices || d.isBt24
      })
      if (found.length === 0) return
      const devices = this.data.devices
      const map = {}
      devices.forEach((d) => { map[d.deviceId] = d })
      found.forEach((d) => { map[d.deviceId] = d })
      const merged = Object.keys(map).map((k) => map[k])
        .sort((a, b) => (b.rssi || -200) - (a.rssi || -200))   // 按信号强弱排序
      this.setData({ devices: merged })
      this.log(`发现 ${found.length} 个设备（共 ${merged.length}）`)
    }
    wx.onBluetoothDeviceFound(this._deviceFoundHandler)

    // 不传 services 过滤：部分透传模块（如 DX-BT24 某些固件）广播包不含 FFE0
    // 服务 UUID，OS 层按服务过滤会直接过滤掉，导致"扫描成功但一个设备都扫不到"
    wx.startBluetoothDevicesDiscovery({
      allowDuplicatesKey: false,
      powerLevel: 'high',
      success: () => {
        this.log('正在扫描附近蓝牙设备...')
        setTimeout(() => this.stopScan(), 10000)
      },
      fail: (err) => {
        this.log('启动扫描失败: ' + JSON.stringify(err))
        this.setData({ discovering: false })
        this.showToast('启动扫描失败，请重试')
      }
    })
  },

  onToggleAll(e) {
    this.setData({ showAllDevices: e.detail.value })
    this.log(e.detail.value ? '显示全部设备' : '只显示 BT24 设备')
    if (this.data.adapterReady && !this.data.connected) {
      this.onStartScan()   // 重新扫描
    }
  },

  stopScan() {
    wx.stopBluetoothDevicesDiscovery({
      complete: () => {
        this.setData({ discovering: false })
        this.log('扫描停止')
      }
    })
  },

  onConnect(e) {
    const deviceId = e.currentTarget.dataset.id
    const device = this.data.devices.find((d) => d.deviceId === deviceId)
    if (!device) return
    wx.showLoading({ title: '连接中...' })
    this.connectDevice(device)
  },

  connectDevice(device, retry = 0) {
    const deviceId = device.deviceId
    this.setData({ deviceName: device.name || '未知设备' })

    wx.createBLEConnection({
      deviceId,
      timeout: 10000,
      success: () => {
        wx.hideLoading()
        this.log('已连接: ' + (device.name || ''))
        this.setData({ connected: true, deviceId })
        this.discoverServices(deviceId)
        this.watchConnectionState(deviceId)
      },
      fail: (err) => {
        const ec = err && err.errCode
        // 断开后系统 BLE 栈可能未及时释放会话（10003 连接失败/10004 已连接/
        // 10012 超时），先关闭残留连接，延时自动重试，最多 3 次
        if (retry < 2) {
          this.log(`连接失败(错误码${ec})，1s 后自动重试 ${retry + 1}/3...`)
          setTimeout(() => {
            wx.closeBLEConnection({
              deviceId,
              complete: () => {
                setTimeout(() => {
                  if (this.data.connected) return
                  this.connectDevice(device, retry + 1)
                }, 600)
              }
            })
          }, 1000)
          return
        }
        wx.hideLoading()
        this.showToast('连接失败，请重试或重新上电设备')
        this.log('连接失败(已重试3次): ' + JSON.stringify(err))
        this.resetConnectedState()
        this.rescan()   // 刷新设备列表，部分系统需新 deviceId 才能重连
      }
    })
  },

  onDisconnect() {
    const deviceId = this.data.deviceId
    if (!deviceId) return
    wx.closeBLEConnection({
      deviceId,
      success: () => this.log('已断开连接'),
      fail: (err) => this.log('断开失败: ' + JSON.stringify(err))
    })
    this.resetConnectedState()
    // 断开后自动重新扫描，方便再次连接
    setTimeout(() => this.rescan(), 300)
  },

  rescan() {
    if (this.data.adapterReady && !this.data.connected) {
      this.onStartScan()
    }
  },

  // 断开后连不上时：重置蓝牙适配器（close→open→自动重扫）
  onResetAdapter() {
    this.resetConnectedState()
    wx.closeBluetoothAdapter({
      complete: () => {
        this.setData({ adapterReady: false, devices: [] })
        this.log('蓝牙适配器已关闭，正在重新打开...')
        wx.openBluetoothAdapter({
          success: () => {
            this.setData({ adapterReady: true })
            this.log('蓝牙适配器已重新打开')
            this.onStartScan()
          },
          fail: (err) => {
            this.log('重新打开适配器失败: ' + JSON.stringify(err))
            this.showToast('重新打开蓝牙失败，请检查系统蓝牙')
          }
        })
      }
    })
  },

  watchConnectionState(deviceId) {
    if (this._connStateHandler) {
      wx.offBLEConnectionStateChange(this._connStateHandler)
    }
    this._connStateHandler = (res) => {
      if (res.deviceId !== deviceId) return
      this.log(res.connected ? '设备重新连接' : '设备已断开')
      if (!res.connected) {
        this.resetConnectedState()
        this.showToast('蓝牙连接已断开')
        this.rescan()
      }
    }
    wx.onBLEConnectionStateChange(this._connStateHandler)
  },

  resetConnectedState() {
    // 清理会话残留，避免重连时使用旧特征 ID / 旧接收缓冲
    this._serviceId = ''
    this._notifyCharId = ''
    this._writeCharId = ''
    this._rxBuffer = ''
    this.setData({
      connected: false,
      deviceId: '',
      deviceName: '',
      loadingCfg: false,
      saving: false
    })
  },

  discoverServices(deviceId) {
    wx.getBLEDeviceServices({
      deviceId,
      success: (res) => {
        const services = res.services || []
        const svc = services.find((s) => (s.uuid || '').toUpperCase().indexOf(SERVICE_UUID) >= 0)
        if (!svc) {
          this.showToast('未找到 FFE0 服务')
          this.log('services: ' + JSON.stringify(services.map((s) => s.uuid)))
          return
        }
        this.log('找到服务 ' + svc.uuid.toUpperCase())
        this.getCharacteristics(deviceId, svc.uuid)
      },
      fail: (err) => {
        this.showToast('获取服务失败')
        this.log('获取服务失败: ' + JSON.stringify(err))
      }
    })
  },

  getCharacteristics(deviceId, serviceId) {
    this._serviceId = serviceId
    wx.getBLEDeviceCharacteristics({
      deviceId,
      serviceId,
      success: (res) => {
        const chars = res.characteristics || []
        const notifyChar = chars.find((c) => {
          const u = (c.uuid || '').toUpperCase()
          return u.indexOf(NOTIFY_CHAR_UUID) >= 0 && c.properties && c.properties.notify
        })
        const writeChar = chars.find((c) => {
          const u = (c.uuid || '').toUpperCase()
          const props = c.properties || {}
          return (u.indexOf(NOTIFY_CHAR_UUID) >= 0 || u.indexOf(WRITE_CHAR_UUID) >= 0) && props.write
        })
        if (!notifyChar) {
          this.showToast('未找到通知特征 FFE1')
          this.log('chars: ' + JSON.stringify(chars.map((c) => ({ u: c.uuid, p: c.properties }))))
          return
        }
        this._notifyCharId = notifyChar.uuid
        this._writeCharId = writeChar ? writeChar.uuid : notifyChar.uuid
        this.enableNotify(deviceId, serviceId, notifyChar.uuid)
      },
      fail: (err) => {
        this.showToast('获取特征失败')
        this.log('获取特征失败: ' + JSON.stringify(err))
      }
    })
  },

  enableNotify(deviceId, serviceId, charId) {
    wx.notifyBLECharacteristicValueChange({
      deviceId,
      serviceId,
      characteristicId: charId,
      state: true,
      success: () => {
        this.log('已订阅通知')
        this.watchNotify()
        // 连接成功后立即读取当前配置
        this.onGetCfg()
      },
      fail: (err) => {
        this.showToast('订阅通知失败')
        this.log('订阅通知失败: ' + JSON.stringify(err))
      }
    })
  },

  watchNotify() {
    if (this._notifyHandler) {
      wx.offBLECharacteristicValueChange(this._notifyHandler)
    }
    this._notifyHandler = (res) => {
      let str = ''
      const buf = new Uint8Array(res.value)
      for (let i = 0; i < buf.length; i++) {
        str += String.fromCharCode(buf[i])
      }
      this._rxBuffer += str
      let nl
      while ((nl = this._rxBuffer.indexOf('\n')) >= 0) {
        const line = this._rxBuffer.slice(0, nl).replace(/\r/g, '').trim()
        this._rxBuffer = this._rxBuffer.slice(nl + 1)
        if (line) this.onLine(line)
      }
    }
    wx.onBLECharacteristicValueChange(this._notifyHandler)
  },

  /* ---------------- 协议处理 ---------------- */

  onLine(line) {
    if (line[0] !== '{') return
    try {
      const obj = JSON.parse(line)
      if (obj.ok !== undefined) {
        this.log('应答: ' + line)
        if (obj.cmd === 'GETCFG' && obj.ok === 1) {
          this.applyCfg(obj)
        } else if (obj.cmd === 'SETCFG') {
          this.setData({ saving: false })
          if (obj.ok === 1 && obj.saved === 1) {
            this.showToast('已保存，设备自动重连', 'success')
            this.log('配置已保存到设备 Flash，MQTT 将自动重连')
          } else {
            this.showToast('保存失败，请检查输入')
          }
        }
      }
    } catch (err) {
      this.log('解析失败: ' + line)
    }
  },

  applyCfg(obj) {
    this.setData({
      wifi_ssid: obj.wifi_ssid || '',
      wifi_password: obj.wifi_password || '',
      broker_host: obj.broker_host || '',
      broker_ip: obj.broker_ip || '',
      broker_port: String(obj.broker_port == null ? '' : obj.broker_port),
      client_id: obj.client_id || '',
      username: obj.username || '',
      password: obj.password || '',
      device_id: obj.device_id || '',
      loadingCfg: false
    })
    this.log('已读取设备当前配置')
  },

  /* ---------------- 表单输入 ---------------- */

  onInput(e) {
    const field = e.currentTarget.dataset.field
    this.setData({ [field]: e.detail.value })
  },

  /* ---------------- 读取 / 保存 ---------------- */

  onGetCfg() {
    if (!this._writeCharId) {
      this.showToast('未连接设备')
      return
    }
    this.setData({ loadingCfg: true })
    this.sendJson({ cmd: 'GETCFG' })
  },

  onSaveCfg() {
    const d = this.data
    if (!this._writeCharId) {
      this.showToast('未连接设备')
      return
    }
    // ---- 校验 ----
    const invalidChar = (v) => /["\\]/.test(v || '')
    const fields = [
      ['WiFi 名称', d.wifi_ssid],
      ['WiFi 密码', d.wifi_password],
      ['云平台地址', d.broker_host],
      ['云平台 IP', d.broker_ip],
      ['ClientId', d.client_id],
      ['用户名', d.username],
      ['云密码', d.password],
      ['设备ID', d.device_id]
    ]
    for (const [name, val] of fields) {
      if (invalidChar(val)) {
        this.showToast(`${name}不能包含 " 或 \\`)
        return
      }
    }
    if (!d.wifi_ssid.trim()) {
      this.showToast('WiFi 名称不能为空')
      return
    }
    if (!d.broker_host.trim() && !d.broker_ip.trim()) {
      this.showToast('云平台地址与IP至少填一个')
      return
    }
    const port = parseInt(d.broker_port, 10)
    if (isNaN(port) || port < 1 || port > 65535) {
      this.showToast('端口需为 1~65535')
      return
    }
    // ---- 确认 ----
    wx.showModal({
      title: '确认保存配置？',
      content: `WiFi: ${d.wifi_ssid}\n云平台: ${d.broker_host || d.broker_ip}:${port}\n保存后设备将自动按新配置重连。`,
      confirmText: '保存',
      cancelText: '取消',
      success: (res) => {
        if (!res.confirm) return
        this.setData({ saving: true })
        this.sendJson({
          cmd: 'SETCFG',
          wifi_ssid: d.wifi_ssid.trim(),
          wifi_password: d.wifi_password,
          broker_host: d.broker_host.trim(),
          broker_ip: d.broker_ip.trim(),
          broker_port: port,
          client_id: d.client_id.trim(),
          username: d.username.trim(),
          password: d.password,
          device_id: d.device_id.trim()
        })
        this.showToast('已下发，等待设备确认', 'none')
      }
    })
  },

  /* ---------------- 发送 ---------------- */

  sendJson(obj) {
    const payload = JSON.stringify(obj) + '\r\n'
    const deviceId = this.data.deviceId
    if (!deviceId || !this._writeCharId) {
      this.showToast('未连接或特征未就绪')
      return
    }
    const chunks = []
    for (let i = 0; i < payload.length; i += 20) {
      chunks.push(payload.slice(i, i + 20))
    }
    this._writeQueue = this._writeQueue.then(() => {
      return chunks.reduce((p, chunk) => {
        return p.then(() => this.writeChunk(deviceId, chunk))
          .then(() => new Promise((r) => setTimeout(r, 40)))
      }, Promise.resolve())
    })
    this.log('发送: ' + JSON.stringify(obj))
  },

  writeChunk(deviceId, chunk) {
    return new Promise((resolve) => {
      const buf = new ArrayBuffer(chunk.length)
      const view = new Uint8Array(buf)
      for (let i = 0; i < chunk.length; i++) {
        view[i] = chunk.charCodeAt(i)
      }
      wx.writeBLECharacteristicValue({
        deviceId,
        serviceId: this._serviceId,
        characteristicId: this._writeCharId,
        value: buf,
        success: () => resolve(),
        fail: (err) => {
          this.log('写入失败: ' + JSON.stringify(err))
          resolve()
        }
      })
    })
  },

  /* ---------------- 清理 ---------------- */

  cleanup() {
    if (this._notifyHandler) {
      wx.offBLECharacteristicValueChange(this._notifyHandler)
      this._notifyHandler = null
    }
    if (this._connStateHandler) {
      wx.offBLEConnectionStateChange(this._connStateHandler)
      this._connStateHandler = null
    }
    if (this._deviceFoundHandler) {
      wx.offBluetoothDeviceFound(this._deviceFoundHandler)
      this._deviceFoundHandler = null
    }
    wx.stopBluetoothDevicesDiscovery({ complete: () => {} })
    if (this.data.deviceId) {
      wx.closeBLEConnection({ deviceId: this.data.deviceId, complete: () => {} })
    }
    wx.closeBluetoothAdapter({ complete: () => {} })
  }
})
